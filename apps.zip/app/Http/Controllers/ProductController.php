<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Product;

class ProductController extends Controller
{
    public function index(Request $request){ 
        $products = Product::latest()->get();  
        if($request->ajax()){
            
            return response()->json($products);
        }else{
            return view("product",["products"=>$products]); 
        }  
    }
    public function store(Request $request)
    {
        $product = new Product();
        $product->name = $request->name;
        $product->quantity = $request->quantity;
        $product->cp = $request->cp;
        $product->dipo = $request->dipo;
        $product->dp = $request->dp;
        $product->tp = $request->tp;
        $product->mrp = $request->mrp;

        if ($request->hasFile('image')) {
            $image = $request->file('image');
            $filename = time() . '.' . $image->getClientOriginalExtension();
            
            // Move করে শুধু public/products এ ফাইল রাখবে
            $image->move(public_path('products'), $filename);

            // DB তে শুধু path সেভ হবে
            $product->image = "products/" . $filename;
        }


        $product->save(); 
        
        return response()->json(['status' => 'success', 'product' => $product]);
    }

    public function update(Request $request, $id)
    {
        $product = Product::findOrFail($id);

        $product->name = $request->name;
        // $product->quantity = $request->quantity;
        $product->cp = $request->cp;
        $product->dipo = $request->dipo;
        $product->dp = $request->dp;
        $product->tp = $request->tp;
        $product->mrp = $request->mrp;

        if ($request->hasFile('image')) {
            // পুরোনো ইমেজ রিমুভ করা
            if ($product->image && file_exists(public_path($product->image))) {
                unlink(public_path($product->image));
            }

            // নতুন ইমেজ আপলোড
            $image = $request->file('image');
            $filename = time() . '.' . $image->getClientOriginalExtension();
            $image->move(public_path('products'), $filename);

            // ডাটাবেজে path সেভ
            $product->image = "products/" . $filename;
        }

        $product->save();

        return response()->json(['status' => 'success', 'product' => $product]);
    }

    public function updateStock(Request $request, $id)
    {
        $product = Product::findOrFail($id);
        $product->quantity = $request->quantity;
        $product->save();

        return response()->json(['status' => 'success', 'product' => $product]);
    }

    public function updateStatus(Request $request, $id)
    {
        $product = Product::findOrFail($id);
        $product->status = $request->status;
        $product->save();

        return response()->json(['success' => true, 'status' => $product->status]);
    }




}
